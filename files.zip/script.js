/* ================================================
   SCRIPT.JS — Digital Product Landing Page
   ================================================
   TABLE OF CONTENTS:
   1.  Sticky Navigation (scroll effect)
   2.  Mobile Hamburger Menu
   3.  FAQ Accordion
   4.  Product Preview Tabs
   5.  Email Signup Form
   6.  Footer Year (auto-updates)
   7.  Scroll Reveal Animations
   ================================================ */


/* ================================================
   HELPER: Run code after the DOM is fully loaded
   ================================================ */
document.addEventListener('DOMContentLoaded', function () {

  /* ================================================
     1. STICKY NAVIGATION
     Adds a "scrolled" class to the navbar once the
     user scrolls past 60px, triggering the frosted-
     glass background via CSS.
     ================================================ */
  const navbar = document.getElementById('navbar');

  function handleNavScroll() {
    if (window.scrollY > 60) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }

  // Run on page load (in case user reloads mid-page)
  handleNavScroll();
  window.addEventListener('scroll', handleNavScroll, { passive: true });


  /* ================================================
     2. MOBILE HAMBURGER MENU
     Toggles the mobile dropdown when the hamburger
     button is clicked. Closes automatically when a
     menu link is clicked.
     ================================================ */
  const hamburger  = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');

  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      const isOpen = mobileMenu.classList.toggle('open');

      // Update accessibility attributes
      hamburger.classList.toggle('open', isOpen);
      hamburger.setAttribute('aria-expanded', isOpen);
      mobileMenu.setAttribute('aria-hidden', !isOpen);

      // Prevent body from scrolling behind open menu
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close menu when any mobile link is tapped
    const mobileLinks = mobileMenu.querySelectorAll('.mobile-link, .mobile-cta');
    mobileLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        mobileMenu.classList.remove('open');
        hamburger.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      });
    });
  }


  /* ================================================
     3. FAQ ACCORDION
     Each FAQ item's button toggles the answer open/
     closed. Only one item can be open at a time
     (accordion behaviour). Remove the "close others"
     block below if you want multi-open behaviour.
     ================================================ */
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(function (item) {
    const btn    = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');

    if (!btn || !answer) return;

    btn.addEventListener('click', function () {
      const isOpen = btn.getAttribute('aria-expanded') === 'true';

      // --- Close ALL other open items (accordion behaviour) ---
      // To allow multiple items open simultaneously, delete the block below.
      faqItems.forEach(function (other) {
        if (other !== item) {
          const otherBtn    = other.querySelector('.faq-question');
          const otherAnswer = other.querySelector('.faq-answer');
          if (otherBtn)    otherBtn.setAttribute('aria-expanded', 'false');
          if (otherAnswer) otherAnswer.classList.remove('open');
        }
      });
      // --- End close-others block ---

      // Toggle the clicked item
      const nowOpen = !isOpen;
      btn.setAttribute('aria-expanded', nowOpen);
      answer.classList.toggle('open', nowOpen);
    });
  });


  /* ================================================
     4. PRODUCT PREVIEW TABS
     Clicking a tab shows the matching preview image
     panel and marks the tab as active.
     ================================================ */
  const previewTabs   = document.querySelectorAll('.preview-tab');
  const previewPanels = document.querySelectorAll('.preview-img');

  previewTabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      const targetIndex = tab.getAttribute('data-tab');

      // Update tab active states
      previewTabs.forEach(function (t) {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      // Show matching panel
      previewPanels.forEach(function (panel) {
        panel.classList.remove('active');
      });
      const targetPanel = document.querySelector('.preview-img[data-panel="' + targetIndex + '"]');
      if (targetPanel) targetPanel.classList.add('active');
    });
  });


  /* ================================================
     5. EMAIL SIGNUP FORM
     Basic client-side validation and a success
     message on submit. Replace the body of the
     handleSubmit function with your real form
     submission logic (e.g. fetch to Mailchimp,
     ConvertKit, Beehiiv, etc.)
     ================================================ */
  const signupForm    = document.getElementById('signupForm');
  const formSuccess   = document.getElementById('formSuccess');
  const emailInput    = document.getElementById('email');
  const firstNameInput = document.getElementById('firstName');

  if (signupForm) {
    signupForm.addEventListener('submit', function (e) {
      e.preventDefault(); // Stop default form POST

      // Simple validation
      const name  = firstNameInput ? firstNameInput.value.trim() : '';
      const email = emailInput ? emailInput.value.trim() : '';

      if (!email || !isValidEmail(email)) {
        emailInput.focus();
        emailInput.style.borderColor = '#f87171';
        setTimeout(function () {
          emailInput.style.borderColor = '';
        }, 2000);
        return;
      }

      /* -----------------------------------------------
         REPLACE THIS BLOCK with your real submission:

         Example using fetch to a form API:

         fetch('https://your-api.com/subscribe', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ name, email })
         })
         .then(res => res.json())
         .then(data => console.log('Subscribed:', data))
         .catch(err => console.error('Error:', err));

         Or use a Mailchimp embed, ConvertKit JS SDK, etc.
      ----------------------------------------------- */
      console.log('Form submitted:', { name, email });

      // Show success state
      signupForm.style.display = 'none';
      if (formSuccess) formSuccess.removeAttribute('hidden');
    });
  }

  /* Email format validator helper */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }


  /* ================================================
     6. FOOTER YEAR
     Automatically updates the copyright year so you
     never have to edit it manually.
     ================================================ */
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }


  /* ================================================
     7. SCROLL REVEAL ANIMATIONS
     Elements with the class "reveal" fade and slide
     in when they enter the viewport. Add the class
     "reveal" to any HTML element you want animated.

     The CSS for the initial hidden state is injected
     here so it only applies when JS is available
     (progressive enhancement).
     ================================================ */

  // Inject base styles for reveal elements
  const revealStyle = document.createElement('style');
  revealStyle.textContent = `
    .reveal {
      opacity: 0;
      transform: translateY(28px);
      transition: opacity 0.65s cubic-bezier(.16,1,.3,1), transform 0.65s cubic-bezier(.16,1,.3,1);
    }
    .reveal.visible {
      opacity: 1;
      transform: none;
    }
    .reveal-delay-1 { transition-delay: 0.1s; }
    .reveal-delay-2 { transition-delay: 0.2s; }
    .reveal-delay-3 { transition-delay: 0.3s; }
    .reveal-delay-4 { transition-delay: 0.4s; }
  `;
  document.head.appendChild(revealStyle);

  // Add "reveal" class to elements you want animated
  // You can also add the class directly in HTML instead
  const revealTargets = document.querySelectorAll(
    '.feature-card, .testimonial-card, .pricing-card, .faq-item, .benefit-item'
  );
  revealTargets.forEach(function (el) {
    el.classList.add('reveal');
  });

  // Add stagger delays to grid children
  document.querySelectorAll('.features-grid, .testimonials-grid, .pricing-cards').forEach(function (grid) {
    const children = grid.querySelectorAll('.reveal');
    children.forEach(function (child, index) {
      if (index % 4 === 1) child.classList.add('reveal-delay-1');
      if (index % 4 === 2) child.classList.add('reveal-delay-2');
      if (index % 4 === 3) child.classList.add('reveal-delay-3');
    });
  });

  // Intersection Observer triggers the animation
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target); // Animate only once
          }
        });
      },
      {
        threshold: 0.12,    // Trigger when 12% of element is visible
        rootMargin: '0px 0px -40px 0px'  // Slight offset from bottom
      }
    );

    document.querySelectorAll('.reveal').forEach(function (el) {
      observer.observe(el);
    });
  } else {
    // Fallback for browsers without IntersectionObserver
    document.querySelectorAll('.reveal').forEach(function (el) {
      el.classList.add('visible');
    });
  }


  /* ================================================
     BONUS: Smooth scroll for all anchor links
     (Fallback for browsers ignoring CSS scroll-behavior)
     ================================================ */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;

      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

}); // End DOMContentLoaded
